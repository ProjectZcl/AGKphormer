import csv
import os

import torch as torch
from train import *
from test import *
from param import *
from utilss import *
import numpy as np
import pandas as pd
import random
import warnings

args = parameter_parser()  # 超参数
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def data_load():
    Adj = pd.read_csv('../data/association_matrix.csv', header=0) #2315*265
    Dis_simi = pd.read_csv('../data/diease_network_simi.csv', header=0) #265*265
    Meta_simi = pd.read_csv('../data/metabolite_ntework_simi.csv', header=0) #2315*2315
    # Adj_next = pd.read_csv('../data/association_matrix.csv', header=0)
    Adj_next = pd.read_csv('../data/association_matrix_completed_admm.csv', header=0)


    train_matrix_root = np.matrix(Adj, copy=True)
    train_matrix_root_next = np.matrix(Adj, copy=True)

    train_matrix = np.matrix(Adj_next, copy=True)  # 将邻接矩阵转化为np矩阵
    train_matrix[:, args.case].fill(0)
    #节点特征矩阵与边索引、边权值
    x = constructHNet(train_matrix_root)
    adj = constructGNet(train_matrix, Meta_simi, Dis_simi)
    adj_list = adj.tolist()
    edge_index = np.array(np.where(adj > 0))#边索引
    edge_attr_list = []
    for i in range(len(edge_index[0])):
        row = edge_index[0][i]
        col = edge_index[1][i]
        edge_attr_list.append(adj_list[row][col])

    for i in range(train_matrix_root_next.shape[1]):  # 提取验证集, 将除了args.case这一列之外的其他元素置为0
        if i == args.case:
            continue
        train_matrix_root_next[:, i].fill(0)

    # 测试集正样本
    val_pos_edge_index = np.mat(np.where(train_matrix_root_next == 1))   # 验证集边索引，正样本
    pd.DataFrame(val_pos_edge_index[0]).to_excel('../result/val_pos_edge_index_crohn.xlsx', index=False)
    # 测试集负采样，采集与正样本相同数量的负样本
    val_neg_edge_index = np.mat(np.where(train_matrix_root < 1)).T.tolist()
    random.shuffle(val_neg_edge_index)
    val_neg_edge_index = val_neg_edge_index[:val_pos_edge_index.shape[1]]
    val_neg_edge_index = np.array(val_neg_edge_index).T
    pd.DataFrame(val_neg_edge_index[0]).to_excel('../result/val_neg_edge_index_crohn.xlsx', index=False)

    # # 获取第  列元素为1的索引
    # val_pos_edge_index = np.array(np.where(train_matrix_root_next[:, args.case] == 1)).T
    # val_pos_edge_index[:, 1] += args.case
    # val_pos_edge_index = val_pos_edge_index.T
    # pd.DataFrame(val_pos_edge_index[0]).to_excel('../result/val_pos_edge_index.xlsx', index=False)
    #
    # val_neg_edge_index = np.mat(np.where(train_matrix_root_next[:, args.case] == 0)).T
    # val_neg_edge_index[:, 1] += args.case
    # val_neg_edge_index = val_neg_edge_index.tolist()
    # # random.seed(args.seed)
    # random.shuffle(val_neg_edge_index)
    # val_neg_edge_index = val_neg_edge_index[:val_pos_edge_index.shape[1]]
    # val_neg_edge_index = np.array(val_neg_edge_index).T
    # pd.DataFrame(val_neg_edge_index[0]).to_excel('../result/val_neg_edge_index.xlsx', index=False)

    #训练集正样本，训练集负样本在epoch内划分，保证更好的可解释性
    train_matrix_root[:, args.case].fill(0)
    train_pos_edge_index = np.mat(np.where(train_matrix_root > 0))  # 训练集边索引，正样本

    data = Data(
        Meta_simi = Meta_simi,
        Adj = torch.tensor(adj, dtype=torch.float).to(device),
        Adj_next = Adj_next,
        train_matrix = torch.tensor(train_matrix, dtype=torch.float).to(device),
        x = torch.tensor(x, dtype=torch.float).to(device),
        edge_index = torch.tensor(edge_index, dtype=torch.long).to(device),
        edge_attr = torch.tensor(edge_attr_list, dtype=torch.float).to(device),  # 边权值
        val_neg_edge_index = torch.tensor(val_neg_edge_index, dtype=torch.long).to(device),  # tensor格式，验证集负样本
        val_pos_edge_index = torch.tensor(val_pos_edge_index, dtype=torch.long).to(device),  # tensor格式，验证集正样本
        train_pos_edge_index = torch.tensor(train_pos_edge_index, dtype=torch.long).to(device)  # tensor格式，训练集正样本
    )
    return data